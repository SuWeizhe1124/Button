import java.awt.Button;
import java.awt.Color;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Java_13_mouse extends Frame implements ActionListener {

	 static int i = 0;
	    Button btn = new Button(); //在這裡宣告Button,actionPerformed才可以用
	    //安排表單內容與註冊事件
	    public Java_13_mouse(){
	        this.setLocation(100,50); //位置
	        this.setTitle("Click"); //標題
	        this.setSize(500,500); //標單寬度,長度
	        this.setVisible(true); //顯示表單
	        this.setLayout(null); //自行定義版面設置

	        btn.setLabel("Press Me!");
	        btn.setBounds(200,200,100,100);
	        btn.setBackground(Color.blue);
	        this.add(btn); //add Button
	        //加入ActionListener介面,以便感受滑鼠事件
	        btn.addActionListener(this); //委派Java_13_mouse處理方式
	    }

	    public static void main(String[] args) {
	        Java_13_mouse frm = new Java_13_mouse();
	    }
	    @Override
	    public void actionPerformed(ActionEvent e) {
	        i++;
	        btn.setLabel(String.valueOf(i));
	    }
}
